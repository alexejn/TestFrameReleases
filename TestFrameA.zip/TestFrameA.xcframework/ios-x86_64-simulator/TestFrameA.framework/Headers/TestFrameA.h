//
//  TestFrameA.h
//  TestFrameA
//
//  Created by alexej_ne on 21.01.2020.
//  Copyright © 2020 BCS. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TestFrameA.
FOUNDATION_EXPORT double TestFrameAVersionNumber;

//! Project version string for TestFrameA.
FOUNDATION_EXPORT const unsigned char TestFrameAVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFrameA/PublicHeader.h>


